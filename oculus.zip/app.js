import express from 'express'

const app = express();
app.use(express.static('public'));

app.listen(8088);   // 8088 production